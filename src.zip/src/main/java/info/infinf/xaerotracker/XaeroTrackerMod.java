package info.infinf.xaerotracker;

import info.infinf.xaerotracker.command.XaeroTrackerCommand;
import info.infinf.xaerotracker.util.MessageUtil;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.concurrent.*;

/**
 * XaeroTracker — Fabric server-side mod.
 *
 * Mirrors the Paper plugin behaviour:
 * - Listens on xaerominimap:main / xaeroworldmap:main plugin channels
 * - Sends player positions to clients with Xaero's Minimap or World Map installed
 * - Supports toggleTracked / toggleTrackEveryone commands
 */
public class XaeroTrackerMod implements ModInitializer {

    public static final String MOD_ID = "xaerotracker";
    public static final Logger LOGGER = LoggerFactory.getLogger("XaeroTracker");

    public static final String MINIMAP_CHANNEL  = "xaerominimap:main";
    public static final String WORLDMAP_CHANNEL = "xaeroworldmap:main";

    public static final Identifier MINIMAP_ID  = Identifier.of("xaerominimap", "main");
    public static final Identifier WORLDMAP_ID = Identifier.of("xaeroworldmap", "main");

    /** Singleton, safe to use after onInitialize */
    public static XaeroTrackerMod INSTANCE;

    // --- State ---
    private final Map<UUID, PlayerData> playerData = new ConcurrentHashMap<>();
    private ScheduledExecutorService trackerThread;
    private FilePlayerList trackIgnoreList;
    private FilePlayerList trackBypassList;
    private XaeroConfig config;

    // --- Custom payloads for Fabric Networking v1 ---

    record MinimapPayload(byte[] data) implements CustomPayload {
        public static final CustomPayload.Id<MinimapPayload> ID = new CustomPayload.Id<>(MINIMAP_ID);
        @Override public CustomPayload.Id<MinimapPayload> getId() { return ID; }
    }

    record WorldMapPayload(byte[] data) implements CustomPayload {
        public static final CustomPayload.Id<WorldMapPayload> ID = new CustomPayload.Id<>(WORLDMAP_ID);
        @Override public CustomPayload.Id<WorldMapPayload> getId() { return ID; }
    }

    // Simple codec: raw byte array prefixed by length (Fabric handles framing)
    private static final PacketCodec<PacketByteBuf, MinimapPayload> MINIMAP_CODEC =
        PacketCodec.of(
            (payload, buf) -> buf.writeBytes(payload.data()),
            buf -> new MinimapPayload(readAllBytes(buf))
        );

    private static final PacketCodec<PacketByteBuf, WorldMapPayload> WORLDMAP_CODEC =
        PacketCodec.of(
            (payload, buf) -> buf.writeBytes(payload.data()),
            buf -> new WorldMapPayload(readAllBytes(buf))
        );

    private static byte[] readAllBytes(PacketByteBuf buf) {
        byte[] bytes = new byte[buf.readableBytes()];
        buf.readBytes(bytes);
        return bytes;
    }

    @Override
    public void onInitialize() {
        INSTANCE = this;

        // Load config
        var configDir = FabricLoader.getInstance().getConfigDir().resolve(MOD_ID);
        config = new XaeroConfig(configDir);
        trackIgnoreList = new FilePlayerList(configDir.resolve("track_ignore_list.txt"));
        trackBypassList = new FilePlayerList(configDir.resolve("track_bypass_list.txt"));

        // Register payload types (both C->S and S->C)
        PayloadTypeRegistry.playC2S().register(MinimapPayload.ID, MINIMAP_CODEC);
        PayloadTypeRegistry.playC2S().register(WorldMapPayload.ID, WORLDMAP_CODEC);
        PayloadTypeRegistry.playS2C().register(MinimapPayload.ID, MINIMAP_CODEC);
        PayloadTypeRegistry.playS2C().register(WorldMapPayload.ID, WORLDMAP_CODEC);

        // Handle incoming packets from Xaero clients (handshake)
        ServerPlayNetworking.registerGlobalReceiver(MinimapPayload.ID, (payload, context) -> {
            var player = context.player();
            var data = payload.data();
            if (data.length >= 5 && data[0] == 1) {
                int version = ((data[1] & 0xFF) << 24) | ((data[2] & 0xFF) << 16) |
                              ((data[3] & 0xFF) << 8)  |  (data[4] & 0xFF);
                trackerThread.submit(() -> {
                    var pd = playerData.computeIfAbsent(player.getUuid(), k -> new PlayerData());
                    pd.setMiniMapNetworkVersion(version);
                    if (pd.hasWorldMap()) {
                        sendRaw(player, WORLDMAP_ID, MessageUtil.getTrackResetMessage());
                    }
                    sendRaw(player, MINIMAP_ID, MessageUtil.getTrackResetMessage());
                    trackOthers(player, MINIMAP_CHANNEL);
                });
            }
        });

        ServerPlayNetworking.registerGlobalReceiver(WorldMapPayload.ID, (payload, context) -> {
            var player = context.player();
            var data = payload.data();
            if (data.length >= 5 && data[0] == 1) {
                int version = ((data[1] & 0xFF) << 24) | ((data[2] & 0xFF) << 16) |
                              ((data[3] & 0xFF) << 8)  |  (data[4] & 0xFF);
                trackerThread.submit(() -> {
                    var pd = playerData.computeIfAbsent(player.getUuid(), k -> new PlayerData());
                    pd.setWorldMapNetworkVersion(version);
                    if (!pd.hasMiniMap()) {
                        trackOthers(player, WORLDMAP_CHANNEL);
                    }
                });
            }
        });

        // Player join
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            var player = handler.player;
            var pd = new PlayerData();
            playerData.put(player.getUuid(), pd);

            // Send handshake + optional levelId
            sendRaw(player, MINIMAP_ID,  MessageUtil.getHandshakeMessage());
            sendRaw(player, WORLDMAP_ID, MessageUtil.getHandshakeMessage());
            if (config.shouldSendLevelId) {
                sendRaw(player, MINIMAP_ID,  MessageUtil.getLevelIdMessage(config.levelId));
                sendRaw(player, WORLDMAP_ID, MessageUtil.getLevelIdMessage(config.levelId));
            }

            trackerThread.submit(() -> track(player, pd));
        });

        // Player disconnect
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            var player = handler.player;
            trackerThread.submit(() -> {
                untrack(player, playerData.get(player.getUuid()));
                playerData.remove(player.getUuid());
            });
        });

        // Register commands
        CommandRegistrationCallback.EVENT.register(XaeroTrackerCommand::register);

        // Lifecycle: start tracker thread on server start, shut down on stop
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            trackerThread = Executors.newSingleThreadScheduledExecutor(r -> {
                var t = new Thread(null, r, "XaeroTracker-Thread", 0);
                t.setDaemon(false);
                t.setPriority(Thread.NORM_PRIORITY);
                return t;
            });
            LOGGER.info("XaeroTracker started. Level ID: {}", config.levelId);
        });

        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            if (trackerThread != null) {
                trackerThread.shutdownNow();
                trackerThread = null;
            }
            playerData.clear();
            LOGGER.info("XaeroTracker stopped.");
        });

        // Position tracking — hook into server tick for move events
        // Fabric doesn't have PlayerMoveEvent, so we use a tick-based approach via mixin.
        // See XaeroTrackerMixin for move detection.

        LOGGER.info("XaeroTracker Fabric mod initialized.");
    }

    // -------------------------------------------------------------------------
    // Tracking logic (ported 1:1 from Paper plugin)
    // -------------------------------------------------------------------------

    public boolean shouldBeTracked(ServerPlayerEntity player) {
        return !trackIgnoreList.contains(player.getName().getString())
            && !player.isInvisible()
            && player.interactionManager.getGameMode() != net.minecraft.world.GameMode.SPECTATOR;
    }

    /** Whether `other` has special permission to always see `player` */
    public boolean shouldBeTrackedBypass(ServerPlayerEntity player, ServerPlayerEntity other) {
        return trackBypassList.contains(other.getName().getString());
    }

    /** Sync `player`'s position to all other online players */
    public void track(ServerPlayerEntity player, PlayerData pd) {
        var msg = MessageUtil.getTrackPlayerMessage(player);
        boolean shouldTrack = shouldBeTracked(player);
        byte[] untrackMsg = null;

        var targets = config.onlySyncSameWorld
            ? player.getServerWorld().getPlayers()
            : player.getServer().getPlayerManager().getPlayerList();

        for (var other : targets) {
            if (other == player) continue;
            var otherData = playerData.get(other.getUuid());
            if (otherData == null || otherData.channel == null) continue;

            if (!shouldTrack && !shouldBeTrackedBypass(player, other)) {
                if (pd.lastShouldTrack) {
                    if (untrackMsg == null) untrackMsg = MessageUtil.getUntrackPlayerMessage(player);
                    sendChannel(other, otherData.channel, untrackMsg);
                }
                continue;
            }
            sendChannel(other, otherData.channel, msg);
        }

        pd.lastShouldTrack = shouldTrack;
        pd.lastSyncTime = System.currentTimeMillis();
    }

    /** Sync all other players' positions to `player` on a given channel */
    public void trackOthers(ServerPlayerEntity player, String channel) {
        var others = config.onlySyncSameWorld
            ? player.getServerWorld().getPlayers()
            : player.getServer().getPlayerManager().getPlayerList();

        for (var other : others) {
            if (other == player) continue;
            if (shouldBeTracked(other) || shouldBeTrackedBypass(other, player)) {
                sendChannel(player, channel, MessageUtil.getTrackPlayerMessage(other));
            }
        }
    }

    /** Send untrack messages for players the client shouldn't see */
    public void hideUntracked(ServerPlayerEntity player) {
        var pd = playerData.get(player.getUuid());
        if (pd == null || pd.channel == null) return;

        var others = config.onlySyncSameWorld
            ? player.getServerWorld().getPlayers()
            : player.getServer().getPlayerManager().getPlayerList();

        for (var other : others) {
            if (other != player && !shouldBeTracked(other) && !shouldBeTrackedBypass(other, player)) {
                sendChannel(player, pd.channel, MessageUtil.getUntrackPlayerMessage(other));
            }
        }
    }

    /** Remove `player` from all other players' maps */
    public void untrack(ServerPlayerEntity player, PlayerData pd) {
        if (pd != null) pd.clearSyncSchedule();
        var msg = MessageUtil.getUntrackPlayerMessage(player);

        var targets = config.onlySyncSameWorld
            ? player.getServerWorld().getPlayers()
            : player.getServer().getPlayerManager().getPlayerList();

        for (var other : targets) {
            if (other == player) continue;
            var otherData = playerData.get(other.getUuid());
            if (otherData != null && otherData.channel != null) {
                sendChannel(other, otherData.channel, msg);
            }
        }
    }

    // -------------------------------------------------------------------------
    // Packet sending helpers
    // -------------------------------------------------------------------------

    public void sendChannel(ServerPlayerEntity player, String channel, byte[] data) {
        if (MINIMAP_CHANNEL.equals(channel)) {
            sendRaw(player, MINIMAP_ID, data);
        } else if (WORLDMAP_CHANNEL.equals(channel)) {
            sendRaw(player, WORLDMAP_ID, data);
        }
    }

    public void sendRaw(ServerPlayerEntity player, Identifier channel, byte[] data) {
        if (!player.networkHandler.isConnectionOpen()) return;
        if (MINIMAP_ID.equals(channel)) {
            ServerPlayNetworking.send(player, new MinimapPayload(data));
        } else if (WORLDMAP_ID.equals(channel)) {
            ServerPlayNetworking.send(player, new WorldMapPayload(data));
        }
    }

    // -------------------------------------------------------------------------
    // Getters
    // -------------------------------------------------------------------------

    public Map<UUID, PlayerData> getPlayerData() { return playerData; }
    public ScheduledExecutorService getTrackerThread() { return trackerThread; }
    public FilePlayerList getTrackIgnoreList() { return trackIgnoreList; }
    public FilePlayerList getTrackBypassList() { return trackBypassList; }
    public XaeroConfig getConfig() { return config; }

    /**
     * Called from the mixin when a player moves.
     * Throttled by syncCooldown.
     */
    public void onPlayerMoved(ServerPlayerEntity player) {
        if (trackerThread == null || trackerThread.isShutdown()) return;
        trackerThread.submit(() -> {
            var pd = playerData.get(player.getUuid());
            if (pd == null) return;
            pd.clearSyncSchedule();
            long elapsed = System.currentTimeMillis() - pd.lastSyncTime;
            if (elapsed >= config.syncCooldown) {
                track(player, pd);
            } else {
                pd.syncSchedule = trackerThread.schedule(
                    () -> track(player, pd),
                    config.syncCooldown - elapsed,
                    TimeUnit.MILLISECONDS
                );
            }
        });
    }
}
