package info.infinf.xaerotracker.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import info.infinf.xaerotracker.XaeroTrackerMod;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

/**
 * /xt command with subcommands:
 *   toggleTracked               - toggle whether YOU can be tracked
 *   toggleTracked <player>      - toggle whether another player can be tracked (op)
 *   toggleTrackEveryone         - toggle bypass (see everyone including hidden) (op)
 *   toggleTrackEveryone <player>- same for another player (op)
 */
public class XaeroTrackerCommand {

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher,
                                CommandRegistryAccess registryAccess,
                                CommandManager.RegistrationEnvironment env) {
        var mod = XaeroTrackerMod.INSTANCE;

        dispatcher.register(
            literal("xt")
                .requires(src -> src.hasPermissionLevel(0)) // anyone can use base command
                .then(literal("toggleTracked")
                    .requires(src -> src.hasPermissionLevel(0))
                    .executes(ctx -> toggleTracked(ctx, null))
                    .then(argument("player", StringArgumentType.word())
                        .requires(src -> src.hasPermissionLevel(2))
                        .executes(ctx -> toggleTracked(ctx, StringArgumentType.getString(ctx, "player")))
                    )
                )
                .then(literal("toggleTrackEveryone")
                    .requires(src -> src.hasPermissionLevel(2))
                    .executes(ctx -> toggleTrackEveryone(ctx, null))
                    .then(argument("player", StringArgumentType.word())
                        .requires(src -> src.hasPermissionLevel(2))
                        .executes(ctx -> toggleTrackEveryone(ctx, StringArgumentType.getString(ctx, "player")))
                    )
                )
        );

        // Also register /xaerotracker as alias
        dispatcher.register(
            literal("xaerotracker")
                .redirect(dispatcher.getRoot().getChild("xt"))
        );
    }

    private static int toggleTracked(CommandContext<ServerCommandSource> ctx, String targetName) {
        var src = ctx.getSource();
        var mod = XaeroTrackerMod.INSTANCE;

        mod.getTrackerThread().submit(() -> {
            if (targetName == null) {
                // Toggle self
                ServerPlayerEntity self;
                try {
                    self = src.getPlayerOrThrow();
                } catch (Exception e) {
                    src.sendError(Text.literal("Must be run as a player"));
                    return;
                }
                boolean nowIgnored = mod.getTrackIgnoreList().toggle(self.getName().getString());
                if (nowIgnored) {
                    src.sendFeedback(() -> Text.literal("✓ You are now hidden from tracking")
                        .formatted(Formatting.GREEN), false);
                } else {
                    src.sendFeedback(() -> Text.literal("✓ You are now visible to tracking")
                        .formatted(Formatting.GREEN), false);
                }
                var data = mod.getPlayerData().get(self.getUuid());
                if (data != null) {
                    mod.track(self, data);
                }
            } else {
                // Toggle other
                boolean nowIgnored = mod.getTrackIgnoreList().toggle(targetName);
                if (nowIgnored) {
                    src.sendFeedback(() -> Text.literal("✓ " + targetName + " is now hidden from tracking")
                        .formatted(Formatting.GREEN), true);
                } else {
                    src.sendFeedback(() -> Text.literal("✓ " + targetName + " is now visible to tracking")
                        .formatted(Formatting.GREEN), true);
                }
                var targetPlayer = src.getServer().getPlayerManager().getPlayer(targetName);
                if (targetPlayer != null) {
                    var data = mod.getPlayerData().get(targetPlayer.getUuid());
                    if (data != null) {
                        mod.track(targetPlayer, data);
                    }
                }
            }
        });
        return 1;
    }

    private static int toggleTrackEveryone(CommandContext<ServerCommandSource> ctx, String targetName) {
        var src = ctx.getSource();
        var mod = XaeroTrackerMod.INSTANCE;

        mod.getTrackerThread().submit(() -> {
            if (targetName == null) {
                ServerPlayerEntity self;
                try {
                    self = src.getPlayerOrThrow();
                } catch (Exception e) {
                    src.sendError(Text.literal("Must be run as a player"));
                    return;
                }
                boolean canTrackAll = mod.getTrackBypassList().toggle(self.getName().getString());
                var selfFinal = self;
                if (canTrackAll) {
                    src.sendFeedback(() -> Text.literal("✓ You can now see all players")
                        .formatted(Formatting.GREEN), false);
                    var data = mod.getPlayerData().get(selfFinal.getUuid());
                    if (data != null && data.channel != null) {
                        mod.trackOthers(selfFinal, data.channel);
                    }
                } else {
                    src.sendFeedback(() -> Text.literal("✓ You can no longer see all hidden players")
                        .formatted(Formatting.GREEN), false);
                    mod.hideUntracked(selfFinal);
                }
            } else {
                boolean canTrackAll = mod.getTrackBypassList().toggle(targetName);
                if (canTrackAll) {
                    src.sendFeedback(() -> Text.literal("✓ " + targetName + " can now see all players")
                        .formatted(Formatting.GREEN), true);
                } else {
                    src.sendFeedback(() -> Text.literal("✓ " + targetName + " can no longer see all hidden players")
                        .formatted(Formatting.GREEN), true);
                }
                var targetPlayer = src.getServer().getPlayerManager().getPlayer(targetName);
                if (targetPlayer != null) {
                    if (canTrackAll) {
                        var data = mod.getPlayerData().get(targetPlayer.getUuid());
                        if (data != null && data.channel != null) {
                            mod.trackOthers(targetPlayer, data.channel);
                        }
                    } else {
                        mod.hideUntracked(targetPlayer);
                    }
                }
            }
        });
        return 1;
    }
}
