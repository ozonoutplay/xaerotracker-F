package info.infinf.xaerotracker.util;

import io.netty.buffer.ByteBufOutputStream;
import io.netty.buffer.Unpooled;
import net.minecraft.server.network.ServerPlayerEntity;

import java.io.IOException;

/**
 * Builds raw byte packets for Xaero's Minimap / World Map plugin channels.
 *
 * Protocol (Xaero network version 3):
 *   Byte 0 = 0  → LevelId packet     (followed by int levelId)
 *   Byte 0 = 1  → Handshake packet   (followed by int protocolVersion=3)
 *   Byte 0 = 2  → TrackPlayer packet (followed by NBT CompoundTag)
 *   Byte 0 = 3  → TrackReset packet  (no data)
 */
public class MessageUtil {

    public static byte[] getLevelIdMessage(int levelId) {
        var buf = Unpooled.buffer(5);
        buf.writeByte(0);
        buf.writeInt(levelId);
        buf.capacity(buf.writerIndex());
        return buf.array();
    }

    public static byte[] getHandshakeMessage() {
        var buf = Unpooled.buffer(5);
        buf.writeByte(1);
        buf.writeInt(3); // protocol version
        buf.capacity(buf.writerIndex());
        return buf.array();
    }

    /**
     * Builds a "track this player" packet.
     * Contains: r=false (not remove), i=UUID int[4], x/y/z doubles, d=dimension key string.
     */
    public static byte[] getTrackPlayerMessage(ServerPlayerEntity player) {
        var buf = Unpooled.buffer(93);
        buf.writeByte(2);

        try (var out = new ByteBufOutputStream(buf)) {
            var uuidArray = UUIDUtil.uuidToIntArray(player.getUuid());
            var pos = player.getPos();
            var dimKey = player.getServerWorld().getRegistryKey().getValue().toString();

            // NBT CompoundTag start (type 10)
            out.writeByte(10);

            // boolean "r" = false (0)
            out.writeByte(1);   // TAG_Byte
            out.writeUTF("r");
            out.writeByte(0);   // false

            // int[] "i" = UUID
            out.writeByte(11);  // TAG_Int_Array
            out.writeUTF("i");
            out.writeInt(uuidArray.length);
            for (int v : uuidArray) {
                out.writeInt(v);
            }

            // double "x"
            out.writeByte(6);
            out.writeUTF("x");
            out.writeDouble(pos.x);

            // double "y"
            out.writeByte(6);
            out.writeUTF("y");
            out.writeDouble(pos.y);

            // double "z"
            out.writeByte(6);
            out.writeUTF("z");
            out.writeDouble(pos.z);

            // string "d" = dimension key
            out.writeByte(8);   // TAG_String
            out.writeUTF("d");
            out.writeUTF(dimKey);

            // TAG_End
            out.writeByte(0);
        } catch (IOException ignored) {
            // Impossible with Netty buffer
        }

        buf.capacity(buf.writerIndex());
        return buf.array();
    }

    /**
     * Builds an "untrack this player" packet.
     * Contains: r=true (remove), i=UUID int[4].
     */
    public static byte[] getUntrackPlayerMessage(ServerPlayerEntity player) {
        var buf = Unpooled.buffer(31);
        buf.writeByte(2);

        try (var out = new ByteBufOutputStream(buf)) {
            var uuidArray = UUIDUtil.uuidToIntArray(player.getUuid());

            out.writeByte(10); // CompoundTag

            // boolean "r" = true (1)
            out.writeByte(1);
            out.writeUTF("r");
            out.writeByte(1);

            // int[] "i" = UUID
            out.writeByte(11);
            out.writeUTF("i");
            out.writeInt(uuidArray.length);
            for (int v : uuidArray) {
                out.writeInt(v);
            }

            out.writeByte(0); // TAG_End
        } catch (IOException ignored) {}

        buf.capacity(buf.writerIndex());
        return buf.array();
    }

    /** Tells the client to clear all tracked players */
    public static byte[] getTrackResetMessage() {
        var buf = Unpooled.buffer(1);
        buf.writeByte(3);
        buf.capacity(buf.writerIndex());
        return buf.array();
    }
}
